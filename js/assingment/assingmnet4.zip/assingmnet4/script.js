const person = {
    name:'john',
    age:30
}

let{name,age } = person;

const message = `my name is ${name} and i am ${age} old`
console.log(message);
